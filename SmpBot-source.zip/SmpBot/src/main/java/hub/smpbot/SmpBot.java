package hub.smpbot;

import com.destroystokyo.paper.profile.ProfileProperty;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class SmpBot extends JavaPlugin implements Listener {

    private NamespacedKey key;
    private final MiniMessage mm = MiniMessage.miniMessage();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        key = new NamespacedKey(this, "smpbot");
        getServer().getPluginManager().registerEvents(this, this);
    }

    private boolean isBot(Entity e) {
        return e instanceof Mannequin
                && e.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    private ResolvableProfile buildProfile() {
        ResolvableProfile.Builder b = ResolvableProfile.resolvableProfile();
        String value = getConfig().getString("skin-value", "");
        String sig = getConfig().getString("skin-signature", "");
        if (!value.isBlank() && !sig.isBlank()) {
            b.addProperty(new ProfileProperty("textures", value, sig));
        } else {
            b.name(getConfig().getString("skin-name", "Notch"));
        }
        return b.build();
    }

    private void spawnBot(Location loc) {
        loc.getWorld().spawn(loc, Mannequin.class, m -> {
            m.setProfile(buildProfile());
            m.setImmovable(true);
            m.setInvulnerable(true);
            m.setPersistent(true);
            m.setRemoveWhenFarAway(false);
            m.customName(mm.deserialize(getConfig().getString("bot-name", "SMP")));
            m.setCustomNameVisible(true);
            m.setDescription(mm.deserialize(getConfig().getString("description", "")));
            m.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        });
    }

    @EventHandler
    public void onClick(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!isBot(e.getRightClicked())) return;
        e.setCancelled(true);
        teleportToSmp(e.getPlayer());
    }

    private void teleportToSmp(Player p) {
        String worldName = getConfig().getString("world", "smp");
        World w = Bukkit.getWorld(worldName);
        if (w == null) {
            p.sendMessage(mm.deserialize(getConfig().getString("messages.world-not-found",
                    "<red>ไม่พบโลก %world%").replace("%world%", worldName)));
            return;
        }
        Location dest;
        if (getConfig().getBoolean("custom-location.enabled", false)) {
            dest = new Location(w,
                    getConfig().getDouble("custom-location.x"),
                    getConfig().getDouble("custom-location.y"),
                    getConfig().getDouble("custom-location.z"),
                    (float) getConfig().getDouble("custom-location.yaw"),
                    (float) getConfig().getDouble("custom-location.pitch"));
        } else {
            dest = w.getSpawnLocation().add(0.5, 0, 0.5);
        }
        p.teleportAsync(dest).thenAccept(ok -> {
            if (ok) {
                p.sendMessage(mm.deserialize(getConfig().getString("messages.teleported",
                        "<green>เทเลพอร์ตไป SMP แล้ว")));
            }
        });
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) return false;
        switch (a[0].toLowerCase()) {
            case "spawn" -> {
                if (!(s instanceof Player p)) { s.sendMessage("ใช้ในเกมเท่านั้น"); return true; }
                spawnBot(p.getLocation());
                s.sendMessage("สร้างบอทแล้ว");
            }
            case "remove" -> {
                if (!(s instanceof Player p)) { s.sendMessage("ใช้ในเกมเท่านั้น"); return true; }
                p.getNearbyEntities(4, 4, 4).stream().filter(this::isBot).findFirst()
                        .ifPresentOrElse(en -> { en.remove(); s.sendMessage("ลบแล้ว"); },
                                () -> s.sendMessage("ไม่พบบอทใกล้ๆ"));
            }
            case "reload" -> {
                reloadConfig();
                s.sendMessage("รีโหลดแล้ว (บอทเดิมต้องลบแล้วสร้างใหม่ถึงจะเปลี่ยนสกิน)");
            }
            default -> { return false; }
        }
        return true;
    }
}
